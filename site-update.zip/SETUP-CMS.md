# Setting up the client editor (Decap CMS)

This adds a login page at **yoursite.netlify.app/admin** where the client can
edit text and swap photos without touching code. Do this once.

> **Honest heads-up:** this setup uses Netlify Identity + Git Gateway to let
> the CMS save changes without your client needing a GitHub account.
> Netlify officially labels Git Gateway "deprecated" — it still works today
> and can still be newly enabled (confirmed against their current docs), but
> they've stopped fixing bugs in it (security issues excepted). Identity
> itself was briefly slated for deprecation too but Netlify reversed that in
> Feb 2026 and it's staying. Practically: this will work fine now and likely
> for a good while, but if Netlify ever pulls the plug on Git Gateway
> entirely, the fix is swapping the CMS backend to GitHub OAuth login
> instead — a config change, not a rebuild. Worth knowing, not worth
> blocking on.

## 1. Upload these files to the GitHub repo

Add everything from this delivery into `github.com/waters-majimaji/TONY-INTERIORS`,
keeping the folder structure:

```
index.html
admin/index.html
admin/config.yml
content/site-content.json
images/  (all files inside)
```

Easiest way: on GitHub, click **Add file → Upload files**, drag in the
`admin`, `content`, and `images` folders plus the new `index.html`, then
commit to `main`. Netlify will auto-deploy since it's already connected.

## 2. Turn on Netlify Identity

In the Netlify dashboard for this site:
- Go to **Site configuration → Identity** → click **Enable Identity**
- Under **Registration**, set it to **Invite only** (so random people can't
  sign up)
- Under **Services → Git Gateway**, click **Enable Git Gateway** — this is
  what lets the CMS save changes back to GitHub on the client's behalf

## 3. Invite your client

Still in **Identity**, click **Invite users**, enter your client's email.
They'll get an email to set a password.

## 4. Hand it over

Give your client this:
- **Editor link:** `https://tonyinteriorsdraft.netlify.app/admin`
- Their email + the password they set from the invite

They log in, click any field or photo, edit it, hit **Publish** — the live
site updates automatically within about a minute. They never see GitHub or
any code.

## What they can edit

Hero text and photo, all 5 service titles/descriptions, all gallery photos,
the before/after photos, the about text and photo, and the WhatsApp
number/link and location text. Everything else (layout, animations, colors)
is locked — they can't accidentally break the design.

## Notes

- If a text edit doesn't show up right away, it's usually mid-deploy —
  Netlify takes ~30–60 seconds to rebuild after Publish.
- If they ever want more fields made editable later, that's a quick addition
  to `admin/config.yml`.
